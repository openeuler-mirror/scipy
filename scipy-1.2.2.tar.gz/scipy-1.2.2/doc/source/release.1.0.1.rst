.. include:: ../release/1.0.1-notes.rst
