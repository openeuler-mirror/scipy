.. automodule:: scipy.signal.windows
