.. _optimize.root_scalar-ridder:

root_scalar(method='ridder')
----------------------------

.. scipy-optimize:function:: scipy.optimize.root_scalar
   :impl: scipy.optimize._root_scalar._root_scalar_ridder_doc
   :method: ridder

