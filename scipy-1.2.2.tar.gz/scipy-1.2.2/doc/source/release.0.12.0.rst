.. include:: ../release/0.12.0-notes.rst
