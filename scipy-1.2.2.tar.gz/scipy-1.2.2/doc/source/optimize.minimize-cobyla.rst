.. _optimize.minimize-cobyla:

minimize(method='COBYLA')
----------------------------------------

.. scipy-optimize:function:: scipy.optimize.minimize
   :impl: scipy.optimize.cobyla._minimize_cobyla
   :method: COBYLA
