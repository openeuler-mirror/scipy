.. _optimize.minimize-tnc:

minimize(method='TNC')
----------------------------------------

.. scipy-optimize:function:: scipy.optimize.minimize
   :impl: scipy.optimize.tnc._minimize_tnc
   :method: TNC
