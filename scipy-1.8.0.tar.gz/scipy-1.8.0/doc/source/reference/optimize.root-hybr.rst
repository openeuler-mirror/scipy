.. _optimize.root-hybr:

root(method='hybr')
----------------------------------

.. scipy-optimize:function:: scipy.optimize.root
   :impl: scipy.optimize._minpack_py._root_hybr
   :method: hybr
