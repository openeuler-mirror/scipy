.. automodule:: scipy.cluster.hierarchy
   :no-members:
   :no-inherited-members:
   :no-special-members:
