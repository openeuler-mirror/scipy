.. _optimize.minimize-powell:

minimize(method='Powell')
----------------------------------------

.. scipy-optimize:function:: scipy.optimize.minimize
   :impl: scipy.optimize._optimize._minimize_powell
   :method: Powell
