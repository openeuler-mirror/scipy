.. _optimize.minimize-neldermead:

minimize(method='Nelder-Mead')
---------------------------------------------

.. scipy-optimize:function:: scipy.optimize.minimize
   :impl: scipy.optimize._optimize._minimize_neldermead
   :method: Nelder-Mead
